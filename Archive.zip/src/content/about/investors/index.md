---
title: "OUR INVESTORS"
slogan: "We successfully raised a total of over 450 million dollar in debt and equity." 
image: "https://thumb.tildacdn.com/tild3934-3137-4364-b862-323361363438/-/resize/560x/-/format/webp/Group_3108.png"
description: " After successfully raising a pre-seed funding, we managed to secure our Series A funding with a combination of debt and equity including our existing shareholder RedAlpine, 468 Capital, Presight Capital, Global Founders Capital and Claret Capital Partners. Including our series A funding we have raised a total of $70 million in debt and equity. Followed by our recent series A+ funding of additional $400 million of capital by Victory Park Capital Advisors and BlackRock.

                        This way we have the opportunity to significantly scale the business. Our shareholder contribute their extensive e-commerce expertise as well as their networks of institutional star investors.

                        In addition, we also have prominent angel investors on board, including serial entrepreneurs & investors such as Mato Peric (CARS24, Choco, Scalable Capital etc.) and Roman Khan (Linjer, Raycon, Lazada etc.) as well as capital market experts such as Manuel Stotz (CEO Kingsway Capital), Stefan Jung (CIO Antler), the Scalable Capital founders Erik Podzuweit & Florian Prucker, and others."
subHeading: "We firmly believe and know from experience that not just the founders, but the entire shareholder group is crucial for a company to succeed"
para: "Suleman Ahmed, Co Founder Bilal-Tech"
path: "/about/investors"
---
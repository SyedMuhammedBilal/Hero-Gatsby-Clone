---
heading: "Get in touch"
title: "Contact us for press inquiries "
slogan: "For general inquiries, please contact us at "
email: press@usehero.com.
email2: "hello@usehero.com."  
path: "/news/contact"
---
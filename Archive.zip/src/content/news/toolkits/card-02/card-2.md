---
id: 2
title: "Using our brand"
description: "These guidelines are here to help you make use of the HERO® logo."
para: "Go to our Brand Guide"
image: "https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/HERO-Brand.jpg"
path: "/news/toolkits"
---
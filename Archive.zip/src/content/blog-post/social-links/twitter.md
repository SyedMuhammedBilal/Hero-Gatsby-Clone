---
link: "https://twitter.com/intent/tweet?url=https%3A%2F%2Fwww.usehero.com%2Fcustomer-stories%2Funtuckit-and-hero-partner-to-help-online-shoppers-find-the-perfect-fit%2F&text=UNTUCKit%20lets%20store%20teams%20connect%20with%20online%20customers%20through%20text%2C%20chat%2C%20and%20video%20call%20with%20Hero's%20powerful%20virtual%20shopping%20tools."
path: "/social-links"
---
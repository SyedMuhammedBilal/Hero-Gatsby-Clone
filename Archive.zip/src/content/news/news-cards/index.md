---
heading: "In the news"
path: "/news/news-cards"
NewsCards: [
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/VogueBusiness.svg',
        title: “VIP clienteling gets a tech makeover.”,
        backgroundColor: "#7a8c6d",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/VogueBusiness.svg',
        title: “Post-pandemic playbook Reviving US department stores.”,
        backgroundColor: "#c29ce5",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/RetailOasis.svg',
        title: “Podcast Ep. 29 - Adam Levene, Founder of HERO®.”,
        backgroundColor: "#035973",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/SourcingJournal.svg',
        title: “Virtual Shopping to the Rescue.”,
        backgroundColor: "#fcb09c",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/TheIndustryFashion.svg',
        title: “Coronavirus closings create virtual consultation uptick in beauty.”,
        backgroundColor: "#7596e5",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/ragtrader.svg',
        title: “Incu customers are 11 times more likely to buy because of this.”,
        backgroundColor: "#7a8c6d",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/WWD.svg',
        title: “Coronavirus closings create virtual consultation uptick in beauty.”,
        backgroundColor: "#c29ce5",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/Charged.svg',
        title: “Virtual shopping is set to be the next major trend in retail.”,
        backgroundColor: "#035973",
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/BOF.svg',
        title: “How to Build a One-on-One Relationship With Your Customer.”,
        backgroundColor: "#fcb09c",
    },
]
---
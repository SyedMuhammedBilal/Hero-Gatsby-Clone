---
title: "Berlin based, Razor buys Amazon FBA merchants that impress with their high product quality and strong customer ratings."
image: "https://images.pexels.com/photos/5011647/pexels-photo-5011647.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940&fbclid=IwAR24xWHZLzsxumzuHOu8MY5I1FmlSUgbMrN0XSZvsheT954fUxEMTxRzEkI"
path: "/about/hero-section"
---
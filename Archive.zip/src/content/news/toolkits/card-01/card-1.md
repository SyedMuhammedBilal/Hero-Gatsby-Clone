---
id: 1
title: "HERO® Marketing Kit"
description: "Everything you need to market and promote Virtual Shopping to your customers 🚀"
para: "Go to our Marketing Kit "
image: "https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/HERO-Marketing-Kit.jpg"
path: "/news/toolkits"
---
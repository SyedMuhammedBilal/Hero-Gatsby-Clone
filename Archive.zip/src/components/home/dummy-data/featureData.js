export const FeatureData = [
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/02/icIllustrationFutureMakeEcommerceHuman.svg',
        title: 'The Human Touch',
        description: 'Bring the personal touch of in-store shopping to your online store.'
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/02/icIllustrationFutureCompetitiveEdge.svg',
        title: 'Your Competitive Edge',
        description: 'Set your online experience apart – empower your store staff, experts or influencers to assist online shoppers.'
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/02/icIllustrationFutureSuperchargeSales.svg',
        title: 'Supercharge Your Sales',
        description: 'With Hero, one in four customers will go on to buy and spend up to 70% more.'
    }
]
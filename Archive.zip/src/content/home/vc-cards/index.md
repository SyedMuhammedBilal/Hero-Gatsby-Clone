---
heading: "WITH YOU. EVERY STEP OF THE WAY."
path: "/home/vc-cards"
button: "meet our team"
link: ""
CardData: [
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/02/icIllustrationCardEasyToGetStarted.svg',
        title: 'EASY TO GET STARTED',
        description: 'Get started with low-touch installation, fast onboarding and dedicated training.'
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/02/icIllustrationCardDedicatedSupport.svg',
        title: 'DEDICATED SUPPORT',
        description: 'Our customer success team will ensure a smooth launch and help you maximize performance.'
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/02/icIllustrationCardGlobalScale.svg',
        title: 'GLOBAL SCALE',
        description: 'Hero is used globally by brands in more than 31 markets across 14 languages.'
    },
]
---
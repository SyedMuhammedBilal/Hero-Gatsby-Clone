---
path: "/blog-list/card-01"
id: 1
slug: "UNTUCKit and HERO® Partner to Help Online Shoppers Find the Perfect Fit"
image: "https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/06/UNTUCKit-Header-1340x894.jpg"
icon: "https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/06/icRetailerTileUntuckit.svg"
description: "In 2010, UNTUCKit Founder and Executive Chairman Chris Riccobono was on the hunt for a shirt that looked good untucked. He quickly realized that it was a hard style to get right—traditional men’s dress shirts were too long and looked sloppy when worn untucked."
subTitle: "Newsroom"
title: "Axel Arigato Launches Virtual Shopping Experience in Partnership With HERO®"
divClass: "item card-item justify-content-center d-flex item-318 col-6"
aClass: "card card-case-study text-white w-100 rounded-0"
figureClass: "card-case-img justify-content-center d-flex text-center mb-0"
date: "June 30,2021"
card: 1
---

<p class="mb-6">After hearing friends echo his frustrations, Chris came up with the idea for UNTUCKit: a polished yet casual shirt designed to be worn untucked. Chris quickly got to work re-engineering the dress shirt with the perfect untucked length to help men look sharp, even at their most casual.</p>

<p>Beyond reimagining the perfect untucked shirt length, Chris focused on reworking contoured hemlines, reinforced collars, and developing a signature sail. Tying it all together is the amount of fits available for every body type: 50+ for every shape and size.</p>

<iframe class="d-flex justify-center" width="670" height="377" src="https://www.youtube.com/embed/M2I1STUCmkw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p class="mb-10">After hearing friends echo his frustrations, Chris came up with the idea for UNTUCKit: a polished yet casual shirt designed to be worn untucked. Chris quickly got to work re-engineering the dress shirt with the perfect untucked length to help men look sharp, even at their most casual.</p>

<p class="mb-10">Beyond reimagining the perfect untucked shirt length, Chris focused on reworking contoured hemlines, reinforced collars, and developing a signature sail. Tying it all together is the amount of fits available for every body type: 50+ for every shape and size.</p>

<img class="mb-10" src='https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/07/1-eXEUpHVSZfCYrXl0tc6WqQ-819x1024.jpeg' />

<h3 class="mb-10">The Perfect UNTUCKit Fit</h3>

<p class="mb-10">In line with their mission to help every customer find the perfect fit, UNTUCKit employs an expert team of highly knowledgeable store associates who offer customers style recommendations and fit expertise. In partnership with Hero, customers shopping online can take advantage of that same knowledge.</p>

<img class="mb-10" src='https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/06/Untuckit-SingleDataCards-1.png') />
<img class="mb-10" src='https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/06/Untuckit-SingleDataCards-2.png') />

<p class="mb-10">“When it comes to finding a classic shirt that looks great and fits well, there’s really no such thing as ‘one size fits all,” says Chris Riccobono, Founder and Executive Chairman, UNTUCKit. “And sometimes finding that perfect fit requires a little extra assistance, which is where our store associates are so helpful. We’re excited to be able to make their expertise available to our online shoppers, so they can find the shirt that helps them look and feel their best.”</p>

---
title: "Exceptional team with 10+ years of experience in e-commerce, building brands and guiding companies."
desc: "We strive to grow, build leading companies and are a team on a joint mission"
path: "/about/gallery"
GalleryData: [
    {
        image: "https://i.pinimg.com/originals/04/5b/d8/045bd85809656d0faa94aa3360f473eb.jpg",
        title: 'Furkan Giray',
        description: 'Vestibulum dapibus odio quam, sit amet hendrerit dui ultricies consectetur. Ut viverra porta leo, non tincidunt mauris condimentu eget. Vivamus non turpis elit. Aenean ultricies nisl sit amet.'
    },
    {
        image: 'https://www.hawtcelebs.com/wp-content/uploads/2021/04/ester-exposito-for-elle-magazine-spain-may-2021-3.jpg',
        title: 'Furkan Giray',
        description: 'Vestibulum dapibus odio quam, sit amet hendrerit dui ultricies consectetur. Ut viverra porta leo, non tincidunt mauris condimentu eget. Vivamus non turpis elit. Aenean ultricies nisl sit amet.'
    },
    {
        image: 'https://wallpapercave.com/wp/wp7905062.jpg',
        title: 'Furkan Giray',
        description: 'Vestibulum dapibus odio quam, sit amet hendrerit dui ultricies consectetur. Ut viverra porta leo, non tincidunt mauris condimentu eget. Vivamus non turpis elit. Aenean ultricies nisl sit amet.'
    },
    {
        image: 'https://www.hawtcelebs.com/wp-content/uploads/2021/04/ester-exposito-for-elle-magazine-spain-may-2021-3.jpg',
        title: 'Furkan Giray',
        description: 'Vestibulum dapibus odio quam, sit amet hendrerit dui ultricies consectetur. Ut viverra porta leo, non tincidunt mauris condimentu eget. Vivamus non turpis elit. Aenean ultricies nisl sit amet.'
    }
] 
---
---
heading: "What's new?"
slogan: "Explore our latest news and industry insights."
path: "/blog-list/content"
button: "latest news"
link: ""
---
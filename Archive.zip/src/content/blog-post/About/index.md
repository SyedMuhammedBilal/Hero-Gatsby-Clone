---
title: "About Hero®"
description: "Add the “IRL” experience to your online store, with the #1 virtual shopping platform. Headquarted in London and New York. Hero is trusted by brands including Levi’s, Nike, Herman Miller and LVMH."
button: "Learn more"
path: "/link/about"
link: ""
---
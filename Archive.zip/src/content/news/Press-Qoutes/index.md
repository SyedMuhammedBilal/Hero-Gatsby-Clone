---
title: "Press Quotes"
PressQoutesData: [
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/GQ.svg',
        title: '“Like facetiming your favorite sales associate”',
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/WWD.svg',
        title: '“Hero ‘humanizes’ online shopping”',
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/SourcingJournal.svg',
        title: '“Shoppers are 21x more likely to buy through Hero"',
    }
] 
path: "/news/press-qoutes"
---
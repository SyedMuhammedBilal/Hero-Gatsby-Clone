---
path: "/about/values"
slogan: "With empathy, qualification and perseverance we are here to take over your Amazon FBA business."
AboutContent: [
    {
        image: 'https://static.tildacdn.com/tild3862-3862-4261-b831-303163616337/ENDOMRAZOR_MOODS_846.jpg',
        title: 'Our Story',
        description: 'We use significant growth capital, paired with extensive e-commerce expertise in order to take these acquired merchants to the next stage of development. Razor is the new-age consumer holding with a clear strategic focus on specific product categories, long-term value enhancement and first-class customer satisfaction. Our young team has a strong vision, excitement for growth and new challenges.',
        left: false,
    },
    {
        image: 'https://thumb.tildacdn.com/tild3632-3238-4161-b963-373663373661/-/resize/560x/-/format/webp/ENDOMRAZOR_MOODS_844.jpg',
        title: 'OUR VALUES & BELIEFS',
        description: 'We believe that almost anyone can aquire companies. However not everyone has access to the resources and expertise to keep a business viable and make it grow. That is what we are here for! With 10+ years of experience in e-commerce, building brands and guiding companies we are confident that we can push your business to the next level.',
        left: true,
    },
]
---
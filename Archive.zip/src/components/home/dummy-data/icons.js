export const iconsData = [
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Nike-1.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Levis-1.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Sephora-1.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48HermanMiller-1.svg'
    }
]
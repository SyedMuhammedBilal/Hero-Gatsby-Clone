---
heading: "One of credos's store managers had an $800 sale on her first try"
subHeading: "Dawn Dobras, CEO - Credo Beauty"
path: "/home/slider"
SliderContent: [
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailerCredo.svg',
        slogan: "Dawn Dobras, CEO - Credo Beauty",
        title: “"One of Credo’s store managers had an $800 sale on her first try"”,
        image: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/imgCarouselCredoAltCrop@2x-933x1024.jpg',
        backgroundColor: "#fcb09c",
        color: "#fa3d3d"
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icQuoteRetailerRagAndBone-1.svg',
        slogan: 'Aaron Detrick, VP Digital - rag & bone',
        title: '“We went on to exceed our initial business case and deliver six-figure sales in the first 12 weeks”',
        image: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/imgCarousel.png',
        backgroundColor: "#035973",
        color: "#c29ce5"
    },
    {
        icon: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailerJonathanAdler.svg',
        slogan: 'Anne Catapano, Head of ecommerce - Jonathan Adler',
        title: '“Helps us bridge the gap between our physical and online showrooms”',
        image: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/imgCarouselJonathanAdlerS@2x-643x1024.jpg',
        backgroundColor: "#144f45",
        color: "#fcb09c"
    }
]

SliderIcons: [
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Nike-1.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Levis-1.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Sephora-1.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48HermanMiller-1.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Annoushka.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48JonathanAdler.svg'
    },
    {
        img: 'https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2021/01/icRetailer48Three.svg'
    }
]
---
---
path: "/blog-list/mega-card"
slug: "Herman Miller Group Extends High-Touch Service to Online Shoppers With HERO®"
icon: "https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/05/icRetailerHermanMiller.svg"
image: "https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/06/UNTUCKit-Header-1340x894.jpg"
description: "In 2010, UNTUCKit Founder and Executive Chairman Chris Riccobono was on the hunt for a shirt that looked good untucked. He quickly realized that it was a hard style to get right—traditional men’s dress shirts were too long and looked sloppy when worn untucked."
title: "Axel Arigato Launches Virtual Shopping Experience in Partnership With HERO®"
scriptSrc: "https://2hrmp9bzmmx3f0xil1wyssgx-wpengine.netdna-ssl.com/wp-content/uploads/2020/05/icRetailerHermanMiller.svg"
cardBody: “Herman Miller Group Extends High-Touch Service to Online Shoppers With HERO®
button: "Read full story"
---